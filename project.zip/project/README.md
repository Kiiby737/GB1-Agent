## 运行环境

Linux；环境依赖见 `environment.yml`，环境名为 `train`。Agent 调用另需 `openai`，ESM2 特征提取另需 `fair-esm`。

## 数据来源



GB1 蛋白适应度数据来源于 Wu et al. (2016) ，相关测序数据公开于 NCBI GEO PRJNA278685

FLIP-GB1数据来源于Fitness Landscape Inference for Proteins 基准数据集提供的 GB1 Sampled 子集（Dallago et al., 2021）。



Wu NC, Dai L, Olson CA, Lloyd-Smith JO, Sun R. (2016). Adaptation in protein fitness landscapes is facilitated by indirect paths. eLife, 5:e16965.

Dallago C, Mou J, Johnston KE, et al. (2021). FLIP: Benchmark tasks in fitness landscape inference for proteins. NeurIPS 2021, Datasets and Benchmarks.

****

## 运行命令

以下均为 Linux Bash 命令。先按 `environment.yml` 配置环境，再填写项目路径、API 密钥、服务地址和可用模型名：

```bash
cd "<PROJECT_ROOT>"
conda activate train
python -m pip install openai fair-esm

export GB1_V44_ROOT="$PWD"
export GB1_DATA_ROOT="$PWD"
export GB1_KG_DIR="$PWD/6.knowledge"
export DEEPSEEK_API_KEY="<填写你的API密钥>"
export DEEPSEEK_BASE_URL="<填写API服务地址>"
export DEEPSEEK_MODEL="<填写可用模型名>"

export GB1_AGENT_RESULT_DIR="$PWD/4.result_runs/VDGV_run1"

python 3.agent/0.initialize_agent_experiments.py --n-initial 20 --seed 114514 --start-sequence VDGV
```

直接将命令中的 `VDGV` 替换为所需的四位起始序列；更换起点或重新开始实验时，使用新的结果目录。

完成上述配置和初始化后，以下两种运行方式任选一种。

单轮推断，输出候选评分、科学评审及 Top-K 推荐（开启知识图谱）：

```bash
python 3.agent/run_agent.py --round 1 --knowledge on --start-sequence VDGV
```

完整多轮实验，分别运行关闭、开启知识图谱两组，每组 3 轮，包含推断、虚拟实验及结果汇总：

```bash
python 3.agent/run_agent_batch.py --start-round 1 --rounds 3 --knowledge off --start-sequence VDGV
python 3.agent/run_agent_batch.py --start-round 1 --rounds 3 --knowledge on --start-sequence VDGV
```

结果保存在 `$GB1_AGENT_RESULT_DIR/no_knowledge/` 和 `$GB1_AGENT_RESULT_DIR/knowledge/`。续跑时将 `--start-round` 改为下一未运行轮次，并保持起始序列及结果目录一致。

如需重新训练 M0，先将相关脚本中的 `<PROJECT_ROOT>` 替换为实际项目根目录，再执行：

```bash
python 2.train/2_train_M0_AL.py
python 3.agent/0.prepare_M0_pool.py
```

## 主要结果

已保存的独立测试结果（1,745 条）：Pearson = 0.8723，Spearman = 0.8580，RMSE = 0.5985，Top-10 重合率 = 70%。

四组实验均采用共享初始 20 条、3 轮每轮新增 20 条的预算；已保存结果如下：

| 方法 | 累计最高 Fitness |
| --- | ---: |
| Random Search | 1.6744 |
| M0-AL Only | 7.5569 |
| LLM Agent OFF | 5.7720 |
| LLM Agent ON | 5.7720 |
