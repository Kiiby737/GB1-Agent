import json

import pandas as pd
from llm_client import generate_json
from agent_paths import get_round_arg, read_observed
from search_strategy import search_state, validate_candidates

AA = 'ACDEFGHIKLMNPQRSTVWY'
POSITIONS = (39, 40, 41, 54)
N_PER_HYPOTHESIS = 20  
BATCH_SIZE = 10
MAX_BATCHES = 5
MAX_CONTROLS_PER_HYPOTHESIS = 3

PROMPT = '''你是 GB1 定向进化的 Mutation Designer，野生型 VDGV，四个字符依次对应39、40、41、54位。
为输入中的【单条假设】提出最多 {n} 条新的四位点候选。请真正使用该假设的 strategy、anchor_variant 和 matched_comparison，而不只是复述假设。

实验目标：既发现更高真实 Fitness 的候选，也检验科学假设；模型评分不是实验结果。
1. 所有策略的额外 test 候选均围绕输入中已测 anchor_variant 的单点邻域设计（与 anchor 恰好相差一个氨基酸）；优先使用 candidate_local_neighbors，而非直接跨越到远处高分序列。
2. strategy=mechanism_validation：优先设计仅在目标位点有差异的 test/control 配对；control 可以与本轮已设计 test 形成单点配对；已测参照不能作为新候选。
3. strategy=knowledge_exploration：在已测 anchor 的邻域内查询 GB1-KG R1-R7、保守/激进替换及历史配对；不得把跨背景实验现象称为当前序列的实测结果。
4. matched_comparison 中的必需 test 由 Python 预先插入，参照为当轮亲本；所有新候选均须在当轮亲本的单点邻域。不要覆盖或重复这些必需候选。
5. 新候选必须在合法四字母序列空间，不能出现在 forbidden_measured、already_proposed、reserved_by_other_hypotheses 中；独立测试集由程序自动过滤；reference_variant 可以是已测序列，但它不是新实验。
6. test/control 只用于本轮真正要测的序列；无法形成有效配对的候选不要假称有严格对照。可用 reference_variant 标明唯一差异位点的参照，必须保证另三位完全相同。
7. 四位点可全部突变；这里的“局部优化”指相对已测 anchor 仅改变一个位点，而不是限制相对野生型的突变数。
8. 不编造 Fitness 或模型预测，不声称理化性质证明有效。reason 简短、准确，不超过35个汉字。
9. 本次尽量生成 {n} 条有效候选，其中尚需的 control 不超过 {controls_needed} 条；不要为了凑数创造无效、已测或不配对的 control。

输出严格 JSON：
{{"candidates":[{{"variant":"LYAG","hypothesis_id":"H1","purpose":"test","reference_variant":"LWAG","reason":"与LWAG比较40位氨基酸差异"}}]}}
reference_variant 可为空字符串；purpose 只能是 test 或 control；hypothesis_id 必须与输入假设一致。
''' 


def site_difference(a, b):
    if not (len(a) == len(b) == 4 and set(a + b) <= set(AA)):
        return None
    differences = [i for i in range(4) if a[i] != b[i]]
    return POSITIONS[differences[0]] if len(differences) == 1 else None


def single_site_neighbors(anchor, eligible, scores):
    possibilities = []
    for i, pos in enumerate(POSITIONS):
        for aa in AA:
            if aa == anchor[i]:
                continue
            variant = anchor[:i] + aa + anchor[i + 1:]
            if variant in eligible:
                possibilities.append({
                    'variant': variant, 'changed_position': pos,
                    'predicted_fitness': round(scores[variant], 4),
                })
    return sorted(possibilities, key=lambda x: -x['predicted_fitness'])


def kg_annotated_neighbors(anchor, eligible, scores, knowledge, paths):
    from kg_agent_knowledge import evaluate_substitution
    options = single_site_neighbors(anchor, eligible, scores)
    for item in options:
        item['kg_evidence'] = evaluate_substitution(
            knowledge, paths, anchor, item['variant'], max_examples=1)
    return options


def choose_anchor(hypothesis, measured_fitness, analysis):
    given = str(hypothesis.get('anchor_variant') or '').strip().upper()
    parent = analysis['search_state']['parent_variant']
    if given and given != parent:
        raise ValueError('Hypothesis anchor cannot leave the user-seeded trajectory')
    if parent not in measured_fitness:
        raise ValueError('Current trajectory parent has no observed label')
    return parent


def mandatory_pair_plan(hypotheses, eligible, measured, measured_fitness, analysis):
    """Validate and reserve every mandatory new variant BEFORE any LLM mutation design."""
    reservations = {}
    owner = {}
    for hypothesis in hypotheses:
        hid = hypothesis['id']
        pair = hypothesis['matched_comparison']
        test = str(pair['test_variant']).strip().upper()
        reference = str(pair['reference_variant']).strip().upper()
        assert site_difference(test, reference) == int(pair['changed_position']), (
            f'{hid}: invalid one-site matched_comparison: {test}/{reference}'
        )
        assert test in eligible, f'{hid}: required test {test} is not an eligible NEW candidate'
        assert reference in measured or reference in eligible, (
            f'{hid}: required reference {reference} is neither measured nor eligible'
        )
        anchor = choose_anchor(hypothesis, measured_fitness, analysis)
        new_members = [test] + ([reference] if reference in eligible else [])
        if hypothesis['strategy'] == 'local_optimization':
            for variant in new_members:
                assert site_difference(variant, anchor) is not None, (
                    f'{hid}: required candidate {variant} is not a 1-site neighbor of {anchor}'
                )
        for variant in new_members:
            
            owner.setdefault(variant, hid)
        reservations[hid] = (test, reference)
    return reservations, owner


def main():
    p = get_round_arg()
    hypotheses = json.loads(p.hypotheses.read_text(encoding='utf-8'))
    analysis = json.loads(p.analysis.read_text(encoding='utf-8'))
    state = search_state(p)
    if analysis.get('search_state') != state:
        raise ValueError('Stale search parent in data analysis')

    observed = read_observed(p)
    measured_fitness = dict(zip(observed['variant'], observed['fitness']))
    measured = set(measured_fitness)
    held_out = set(pd.read_csv(p.test, usecols=['variant'])['variant'].str.upper())
    pool = pd.read_csv(p.predictions, usecols=['variant', 'predicted_fitness'])
    pool['variant'] = pool['variant'].str.upper()
    eligible = set(pool['variant']) - measured - held_out
    scores = dict(zip(pool['variant'], pool['predicted_fitness']))

    candidates, proposed = [], set()

    def add(variant, hypothesis, purpose, reason, reference='', method='llm'):
        variant = str(variant).strip().upper()
        reference = str(reference or '').strip().upper()
        strategy = hypothesis.get('strategy', 'mechanism_validation')
        anchor = choose_anchor(hypothesis, measured_fitness, analysis)
        if variant not in eligible or variant in proposed or purpose not in ('test', 'control'):
            return False
        if site_difference(variant, anchor) is None:
            return False  
        if strategy == 'local_optimization' and method != 'hypothesis_pair':
            reference = anchor  
        if reference and (reference not in measured and reference not in eligible):
            reference = ''  
        if reference and site_difference(variant, reference) is None:
            reference = ''
        if not reference and site_difference(variant, anchor) is not None:
            reference = anchor
        pos = site_difference(variant, reference) if reference else None
        if purpose == 'control' and (not reference or (reference not in measured and reference not in proposed)):
            return False  
        if purpose == 'control' and sum(c['purpose'] == 'control' and c['hypothesis_id'] == hypothesis['id'] for c in candidates) >= MAX_CONTROLS_PER_HYPOTHESIS:
            return False
        if strategy == 'local_optimization':
            reason = f'{anchor}的{pos}位单点替换候选' if reference == anchor else f'{anchor}的单点邻域优化'
        row = {
            'variant': variant, 'hypothesis_id': hypothesis['id'], 'purpose': purpose,
            'reason': str(reason)[:35], 'strategy': strategy,
            'anchor_variant': anchor,
            'reference_variant': reference,
            'changed_position': pos if pos else '',
            'reference_status': ('measured' if reference in measured else
                                 'proposed_new' if reference in proposed else
                                 'unmeasured_not_selected' if reference else 'none'),
            'design_method': method,
        }
        if 'knowledge' in analysis:
            from kg_agent_knowledge import evaluate_substitution

            base = reference if reference in measured else anchor
            evidence = evaluate_substitution(analysis['knowledge'], p, base, variant)
            row['kg_substitution'] = evidence['substitution'] if evidence else ''
            row['kg_conservative'] = evidence['conservative_heuristic'] if evidence else None
            row['kg_other_background_n'] = evidence['other_background_n'] if evidence else 0
            row['kg_other_background_median_delta'] = (
                evidence['other_background_median_delta'] if evidence else None)
            row['kg_evidence_reference'] = base if evidence else ''
            row['kg_rule_ids'] = ';'.join(evidence['knowledge_rules']) if evidence else ''
        candidates.append(row)
        proposed.add(variant)
        return True

    hypothesis_list = hypotheses['hypotheses']
    reservations, owners = mandatory_pair_plan(
        hypothesis_list, eligible, measured, measured_fitness, analysis
    )


    for hypothesis in hypothesis_list:
        hid = hypothesis['id']
        test, reference = reservations[hid]
        if test not in proposed:
            assert add(test, hypothesis, 'test', '来自假设的必需单点配对',
                       reference, 'hypothesis_pair'), f'{hid}: could not reserve test {test}'
        if reference in eligible and reference not in proposed:
            assert add(reference, hypothesis, 'control', '来自假设的必需新测对照',
                       test, 'hypothesis_pair'), f'{hid}: could not reserve control {reference}'
        print(f'{hid}: mandatory comparison reserved {test}/{reference}', flush=True)


    for hypothesis in hypothesis_list:
        hid = hypothesis['id']
        strategy = hypothesis.get('strategy', 'mechanism_validation')
        anchor = choose_anchor(hypothesis, measured_fitness, analysis)
        if 'knowledge' in analysis:
            local = kg_annotated_neighbors(anchor, eligible - set(owners), scores,
                                           analysis['knowledge'], p)
        else:
            local = single_site_neighbors(anchor, eligible - set(owners), scores)

        def group_rows():
            return [c for c in candidates if c['hypothesis_id'] == hid]

        if 'knowledge' in analysis:
            from kg_agent_knowledge import knowledge_suggestions

            tips = knowledge_suggestions(anchor, eligible - proposed - set(owners),
                                         scores, analysis['knowledge'], p, limit=8)
            used_classes = set()
            for tip in tips:
                is_conservative = tip['evidence']['conservative_heuristic']
                if is_conservative in used_classes:
                    continue
                used_classes.add(is_conservative)
                label = 'R3:保守替换对照' if is_conservative else 'R3:激进替换对照'
                add(tip['variant'], hypothesis, 'test', label, anchor, 'kg_rule_proposal')

        for batch_no in range(1, MAX_BATCHES + 1):
            accepted = len(group_rows())
            if accepted >= N_PER_HYPOTHESIS:
                break
            n = min(BATCH_SIZE, N_PER_HYPOTHESIS - accepted)
            n_controls = sum(c['purpose'] == 'control' for c in group_rows())
            payload = {
                'hypothesis': hypothesis,
                'anchor': {'variant': anchor, 'measured_fitness': float(measured_fitness[anchor])},
                'candidate_local_neighbors': [x for x in local if x['variant'] not in proposed][:30],
                'top_observed': analysis['observed']['top_variants'],
                'top_predicted': analysis['predicted']['top_variants'],
                'top100_vs_pool': analysis['predicted']['top100_vs_pool'],
                'last_round': analysis['last_round'],
                'forbidden_measured': sorted(measured),
                'already_proposed': sorted(proposed),
                'reserved_by_other_hypotheses': sorted(
                    v for v, owner in owners.items() if owner != hid
                ),
            }
            design_prompt = PROMPT.format(n=n, controls_needed=max(0, 2 - n_controls))
            if 'knowledge' in analysis:
                from kg_agent_knowledge import focused_knowledge, knowledge_suggestions
                payload['knowledge'] = focused_knowledge(analysis['knowledge'])
                payload['knowledge_design'] = hypothesis.get('knowledge_design')
                payload['kg_suggestions'] = knowledge_suggestions(
                    anchor, eligible - proposed - set(owners), scores,
                    analysis['knowledge'], p, limit=8)
                design_prompt += (
                    '\nKnowledge ON：根据 GB1-KG 的 R1-R7、保守/激进替换、'
                    '同背景已测单点配对及跨背景弱证据提出候选。'
                    'kg_suggestions 属于允许但未测的替换。'
                    '不得将理化性质或跨背景平均效果当成候选真实 Fitness。'
                    '不使用 AAKG 距离窗口，也不对预测 Fitness 加知识奖励。'
                )
            response = generate_json(
                design_prompt, payload,
                debug_file=p.folder / f'invalid_mutation_{hypothesis["id"]}_batch{batch_no}.txt',
            )
            before = len(candidates)
            for item in sorted(response['candidates'], key=lambda c: c.get('purpose') == 'control'):
                if len(group_rows()) >= N_PER_HYPOTHESIS:
                    break
                if item.get('hypothesis_id') != hypothesis['id']:
                    continue
                if str(item['variant']).strip().upper() in owners:
                    continue  
                add(item['variant'], hypothesis, item.get('purpose'),
                    item.get('reason', ''), item.get('reference_variant', ''), 'llm')
            print(f'{hypothesis["id"]}, batch {batch_no}: received {len(response["candidates"])} / '
                  f'accepted {len(candidates) - before}, total {len(group_rows())}/{N_PER_HYPOTHESIS}', flush=True)


        if len(group_rows()) < N_PER_HYPOTHESIS:
            for entry in local:
                if len(group_rows()) >= N_PER_HYPOTHESIS:
                    break
                add(entry['variant'], hypothesis, 'test', '当轮亲本的单点邻域', anchor, 'local_fallback')

        assert any(c['purpose'] == 'test' for c in group_rows()) or reservations[hid][0] in proposed, (
            f'{hid}: no test survived candidate design'
        )
        rows = group_rows()
        paired = sum(bool(c['reference_variant']) for c in rows)
        print(f'{hypothesis["id"]}: strategy={strategy}, anchor={anchor}, '
              f'accepted={len(rows)}, paired_to_reference={paired}, '
              f'controls={sum(c["purpose"] == "control" for c in rows)}', flush=True)

    assert len(candidates) >= 20, f'Only {len(candidates)} eligible candidates in total; need at least 20'
    frame = pd.DataFrame(candidates)

    selected_variants = set(frame['variant'])
    frame.loc[frame['reference_variant'].isin(selected_variants) &
              ~frame['reference_variant'].isin(measured), 'reference_status'] = 'new_candidate'
    assert frame['variant'].is_unique
    assert not (set(frame['variant']) & (measured | held_out))
    validate_candidates(p, frame, state)
    frame.to_csv(p.designed, index=False)
    print(f'Mutation Designer complete: {len(frame)} eligible candidates -> {p.designed}')


if __name__ == '__main__':
    main()
