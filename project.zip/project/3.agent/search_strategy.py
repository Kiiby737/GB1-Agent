import hashlib
import json
import math
from pathlib import Path

import pandas as pd

import agent_paths as ap

AA = set('ACDEFGHIKLMNPQRSTVWY')
WT = 'VDGV'
PROTOCOL = 'seeded-single-site-trajectory-1'
BATCH_SIZE = 20


def normalize_start(value=None):
    value = str(value or WT).strip().upper() or WT
    if len(value) != 4 or not set(value) <= AA:
        raise ValueError('Starting variant must contain exactly 4 canonical amino-acid letters, e.g. VDGV')
    return value


def hamming(a, b):
    return sum(x != y for x, y in zip(a, b))


def start_file():
    return ap.AGENT_RESULT_DIR / 'search_start.json'


def load_start():
    path = start_file()
    if not path.exists():
        raise FileNotFoundError('Starting sequence is not initialized; run run_agent.py first')
    start = json.loads(path.read_text(encoding='utf-8'))
    if start.get('protocol') != PROTOCOL or normalize_start(start['variant']) != start['variant']:
        raise ValueError('Unsupported starting-sequence metadata')
    if not math.isfinite(float(start['fitness'])):
        raise ValueError('Starting-sequence fitness is not finite')
    if start.get('input_sha256') != input_fingerprints():
        raise ValueError('Seeded experiment inputs changed; choose a new output directory')
    return start


def input_fingerprints():
    result = {}
    for name, path in [('m0', ap.INITIAL_FILE), ('initial20', ap.AGENT_INITIAL_FILE),
                       ('heldout', ap.TEST_FILE), ('prediction_pool', ap.POOL_PREDICTIONS)]:
        digest = hashlib.sha256()
        with Path(path).open('rb') as handle:
            for block in iter(lambda: handle.read(1024 * 1024), b''):
                digest.update(block)
        result[name] = digest.hexdigest()
    return result


def initialize_search(requested=None):
    """Reuse a known seed label, or reveal ONLY that seed once as a baseline."""
    if start_file().exists():
        start = load_start()
        if requested is not None and normalize_start(requested) != start['variant']:
            raise ValueError('Cannot change the starting sequence of an existing run; use a new GB1_AGENT_RESULT_DIR')
        return start

    if any(ap.AGENT_RESULT_DIR.glob('*/round_*/experiment_results.csv')):
        raise ValueError('Legacy rounds have no seed lineage; use a new GB1_AGENT_RESULT_DIR')
    seed = normalize_start(requested)
    heldout = set(pd.read_csv(ap.TEST_FILE, usecols=['variant'])['variant'].astype(str).str.upper().str.strip())
    if seed in heldout:
        raise ValueError('Starting sequence belongs to the independent test set; choose another sequence')
    batches = [pd.read_csv(ap.INITIAL_FILE, usecols=['variant', 'fitness']),
               pd.read_csv(ap.AGENT_INITIAL_FILE, usecols=['variant', 'fitness'])]
    history = pd.concat(batches, ignore_index=True)
    history['variant'] = history['variant'].astype(str).str.upper().str.strip()
    matches = history.loc[history['variant'] == seed, 'fitness']
    if len(matches) > 1:
        raise ValueError('Seed has duplicate historical labels')
    if len(matches):
        fitness = float(matches.iloc[0]); source = 'already_visible_history'; queries = 0
    else:
        selected = []
        for chunk in pd.read_csv(ap.ORACLE_FILE, usecols=['AACombo', 'Fitness'], chunksize=50000):
            ids = chunk['AACombo'].astype(str).str.upper().str.strip()
            selected.extend(chunk.loc[ids == seed, 'Fitness'].tolist())
        if len(selected) != 1:
            raise ValueError(f'Starting sequence {seed} has no unique offline Oracle label')
        fitness = float(selected[0]); source = 'single_seed_oracle_query'; queries = 1
    if not math.isfinite(fitness):
        raise ValueError('Starting sequence has non-finite fitness')
    start = {'protocol': PROTOCOL, 'variant': seed, 'fitness': fitness, 'source': source,
             'seed_oracle_queries': queries, 'same_seed_for_both_modes': True,
             'count_as_new_round_experiment': False,
             'input_sha256': input_fingerprints(),
             'parent_policy': 'highest_fitness_seed_or_branch_descendant_with_enough_unmeasured_one_site_neighbors'}
    ap.AGENT_RESULT_DIR.mkdir(parents=True, exist_ok=True)
    start_file().write_text(json.dumps(start, indent=2), encoding='utf-8')
    return start


def search_state(paths, minimum_candidates=BATCH_SIZE):
    start = load_start()
    observed = ap.read_observed(paths)
    heldout = set(pd.read_csv(paths.test, usecols=['variant'])['variant'])
    pool = set(pd.read_csv(paths.predictions, usecols=['variant'])['variant'])
    eligible = pool - set(observed['variant']) - heldout
    trajectory = [{'variant': start['variant'], 'fitness': float(start['fitness']), 'discovered_round': 0}]
    seen = {start['variant']}
    history_fingerprints = {}
    for number in range(1, paths.round_num):
        folder = ap.existing_round_folder(number)
        previous = json.loads((folder / 'search_state.json').read_text(encoding='utf-8'))
        if previous.get('protocol') != PROTOCOL or previous['start_variant'] != start['variant']:
            raise ValueError('Previous round belongs to another starting sequence or search protocol')
        parent = previous['parent_variant']
        if parent not in seen:
            raise ValueError('Previous round parent was not in the seed trajectory')
        result_path = folder / 'experiment_results.csv'
        data = pd.read_csv(result_path, usecols=['variant', 'fitness'])
        if len(data) != BATCH_SIZE or not data['variant'].is_unique:
            raise ValueError('Previous trajectory round must contain 20 unique new experiments')
        for row in data.itertuples(index=False):
            variant = str(row.variant).strip().upper()
            if variant in seen or hamming(parent, variant) != 1 or not math.isfinite(float(row.fitness)):
                raise ValueError('Previous experiment is repeated or leaves its recorded one-site parent')
            seen.add(variant)
            trajectory.append({'variant': variant, 'fitness': float(row.fitness), 'discovered_round': number})
        history_fingerprints[str(number)] = hashlib.sha256(result_path.read_bytes()).hexdigest()
    ranked = sorted(trajectory, key=lambda row: (-row['fitness'], row['discovered_round'], row['variant']))
    choices = []
    for row in ranked:
        parent = row['variant']
        neighbors = {parent[:i] + aa + parent[i+1:] for i in range(4) for aa in AA if aa != parent[i]}
        count = len(neighbors & eligible)
        if count >= minimum_candidates:
            choices.append((row, count))
    if not choices:
        raise ValueError(f'No seed/descendant parent has {minimum_candidates} eligible single-site neighbors; no global-history jump is allowed')
    selected, count = choices[0]
    state = {'protocol': PROTOCOL, 'round': paths.round_num, 'knowledge_mode': paths.knowledge_mode,
             'start_variant': start['variant'], 'parent_variant': selected['variant'],
             'parent_fitness': selected['fitness'], 'parent_discovered_round': selected['discovered_round'],
             'trajectory_observed_count': len(trajectory), 'eligible_neighbor_count': count,
             'minimum_candidates': minimum_candidates, 'previous_round_sha256': history_fingerprints}
    target = paths.folder / 'search_state.json'
    if target.exists():
        if json.loads(target.read_text(encoding='utf-8')) != state:
            raise ValueError('Search state changed while resuming a round')
    else:
        paths.folder.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(state, indent=2), encoding='utf-8')
    return state


def validate_candidates(paths, candidates, state=None):
    state = state or search_state(paths)
    parent = state['parent_variant']
    forbidden = set(ap.read_observed(paths)['variant']) | set(pd.read_csv(paths.test, usecols=['variant'])['variant'])
    for row in candidates.to_dict('records'):
        variant = str(row['variant']).strip().upper()
        if len(variant) != 4 or not set(variant) <= AA or hamming(parent, variant) != 1:
            raise ValueError(f'Candidate {variant} must be a single-site neighbor of current parent {parent}')
        if variant in forbidden:
            raise ValueError(f'Candidate {variant} is already measured or held out')
        if 'anchor_variant' in row and str(row['anchor_variant']).strip().upper() != parent:
            raise ValueError('Candidate anchor left the user-seeded trajectory')
    return state
