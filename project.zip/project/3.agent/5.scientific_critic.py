import json
from collections import Counter

import pandas as pd

from llm_client import generate_json
from agent_paths import get_round_arg, read_observed
from search_strategy import search_state, validate_candidates

TOP_K = 20
REVIEW_BATCH_SIZE = 12  
TARGET_LOCAL_TESTS = 10
TARGET_OTHER_TESTS = 6
MAX_NEW_CONTROLS = 4
KG_VALIDATION_SLOTS = 2  
POSITIONS = (39, 40, 41, 54)
AA = set('ACDEFGHIKLMNPQRSTVWY')

PROMPT = '''你是 GB1 定向进化 Agent 的 Scientific Critic。野生型四位点是 VDGV，variant 的四个字符分别为39、40、41、54位。
请审查【所有】候选与三条科学假设；你的判断仅用于科学解释，最终实验配额由 Python 确定性选择。

1. 明确区分：已测真实 fitness、固定 M0-AL predicted_fitness、uncertainty、自建 GB1-KG 的理化属性和历史已测单点配对。
2. candidate_facts 是 Python 验证过的位点和参照证据。只有其 comparison_status 为 measured_pair 或 candidate_pair 才能声称严格单点配对；unpaired 不得写成控制变量实验。
3. 已测参照可以用于比较，但不能作为新的实验候选，也不消耗新实验预算。
4. 如果 reference_variant 是另一条新候选，只有二者都被最终选择并查询 Oracle，才构成这轮完整的新实验配对。
5. 从上一轮真实实验分析每条假设受支持、受到挑战或仍缺乏证据的情况；不要用预测得分证明机制成立。
6. 单点差异不能独自证明两位点上位性；要检验协同需要在一致背景下设计2×2比较。
7. 即使某条候选与假设的预测方向矛盾，也可能具有证伪价值；指出其作用，而不是一律排除。
8. 禁止编造 Fitness、文献和位点；引用 knowledge 时区分通用性质和 GB1 已测证据，不得把理化性质等同于实测改进。

仅输出 JSON：
{
  "hypothesis_assessments": [
    {"hypothesis_id":"H1","assessment":"模型支持|证据不足|模型不支持","reason":"综合评价"}
  ],
  "reviews": [
    {"variant":"LYAG","hypothesis_alignment":"符合|不确定|矛盾",
     "scientific_reason":"解释设计依据及证据","limitations":"证据缺口与必要对照"}
  ]
}
必须为输入的每条假设输出一条 assessment，且为每条 candidate 输出一条 review。
'''


def single_changed_position(a, b):
    if len(a) != 4 or len(b) != 4 or not set(a + b) <= AA:
        return None
    changed = [i for i in range(4) if a[i] != b[i]]
    return POSITIONS[changed[0]] if len(changed) == 1 else None


def prepare_candidates(scored, hypotheses):
    frame = scored.copy()
    frame['variant'] = frame['variant'].astype(str).str.upper().str.strip()
    assert frame['variant'].is_unique, 'Duplicate variant in scored_candidates.csv'
    for col in ('reference_variant', 'strategy', 'anchor_variant', 'design_method'):
        if col not in frame:
            frame[col] = ''
        frame[col] = frame[col].fillna('').astype(str).str.strip()
    frame['reference_variant'] = frame['reference_variant'].str.upper()
    frame['anchor_variant'] = frame['anchor_variant'].str.upper()
    strategies = {h['id']: h.get('strategy', 'mechanism_validation') for h in hypotheses}
    frame['strategy'] = frame.apply(
        lambda r: r['strategy'] or strategies[r['hypothesis_id']], axis=1)
    assert frame['purpose'].isin(['test', 'control']).all(), 'Invalid purpose'
    assert frame['variant'].map(lambda v: len(v) == 4 and set(v) <= AA).all()
    return frame.sort_values('predicted_fitness', ascending=False).reset_index(drop=True)


def build_pair_facts(scored, observed):
    """All comparisons use exact 1-site differences; observed excludes the hidden Oracle."""
    fitness = dict(zip(observed['variant'].astype(str).str.upper(), observed['fitness']))
    rows = scored.set_index('variant').to_dict('index')
    facts = {}
    for variant, row in rows.items():
        ref = row['reference_variant']
        position = single_changed_position(variant, ref)
        if position is not None and ref in fitness:
            status = 'measured_pair'
        elif position is not None and ref in rows:
            status = 'candidate_pair'
        else:
            status = 'unpaired'
        facts[variant] = {
            'variant': variant,
            'site_39_40_41_54': {str(pos): aa for pos, aa in zip(POSITIONS, variant)},
            'mutations_from_wt': [f'{wt}{pos}{aa}' for wt, pos, aa in zip('VDGV', POSITIONS, variant) if wt != aa],
            'reference_variant': ref if status != 'unpaired' else None,
            'comparison_status': status,
            'changed_position': position if status != 'unpaired' else None,
            'reference_measured_fitness': float(fitness[ref]) if status == 'measured_pair' else None,
        }
    return facts


def selection_priority(scored, knowledge=None):
    """Identical frozen M0-AL prediction ranking in ON and OFF, no KG pseudo-fitness."""
    ordered = scored.sort_values(['predicted_fitness', 'variant'], ascending=[False, True])
    n = len(ordered)
    return {v: (n - i) / n for i, v in enumerate(ordered['variant'])}


def select_topk(scored, observed, hypotheses, top_k=TOP_K, knowledge=None, parent_variant=None):
    """Choose 20 variants, prioritizing all-hypothesis coverage and real paired tests.

    Targets: <=10 local tests, <=6 other tests, <=4 valid new controls.
    If available test/control pairs or categories are insufficient, quotas are soft;
    fill with highest-predicted remaining tests, never orphan controls.
    """
    df = prepare_candidates(scored, hypotheses)
    if parent_variant is not None:
        if (not df['anchor_variant'].eq(parent_variant).all()
                or not df['variant'].map(lambda value: single_changed_position(value, parent_variant) is not None).all()):
            raise ValueError('Scored candidates left the current parent neighborhood')
    facts = build_pair_facts(df, observed)
    rows = {r['variant']: r for r in df.to_dict('records')}
    priorities = selection_priority(df, knowledge)
    ordered_tests = sorted(
        (v for v in df['variant'] if rows[v]['purpose'] == 'test'),
        key=lambda v: (-priorities[v], -float(rows[v]['predicted_fitness']), v))
    ordered_controls = sorted(
        (v for v in df['variant'] if rows[v]['purpose'] == 'control'),
        key=lambda v: (-priorities[v], -float(rows[v]['predicted_fitness']), v))
    missing_test_hypotheses = [
        h['id'] for h in hypotheses
        if not any(rows[v]['hypothesis_id'] == h['id'] for v in ordered_tests)
        and h['matched_comparison']['test_variant'] not in rows
    ]
    assert not missing_test_hypotheses, (
        f'No valid test candidate for {missing_test_hypotheses}; '
        'rerun module 3 to design tests instead of selecting only controls.'
    )
    selected = []
    selected_set = set()
    assigned_control_to_test = {}
    target_local = round(TARGET_LOCAL_TESTS * top_k / TOP_K)
    target_other = round(TARGET_OTHER_TESTS * top_k / TOP_K)
    max_controls = round(MAX_NEW_CONTROLS * top_k / TOP_K)

    def local(v):
        return rows[v]['strategy'] == 'local_optimization'

    def n_tests(is_local):
        return sum(rows[v]['purpose'] == 'test' and local(v) == is_local for v in selected)

    def add(v):
        if v not in selected_set and len(selected) < top_k:
            selected.append(v)
            selected_set.add(v)
            return True
        return False


    new_pairs = []
    for test in ordered_tests:
        for ctrl in ordered_controls:
            if rows[test]['hypothesis_id'] != rows[ctrl]['hypothesis_id']:
                continue
            if single_changed_position(test, ctrl) is None:
                continue
            if rows[test]['reference_variant'] == ctrl or rows[ctrl]['reference_variant'] == test:
                new_pairs.append((test, ctrl))
    pair_test_set = {t for t, c in new_pairs}


    required_control_variants = set()
    measured_variants = set(observed['variant'].astype(str).str.upper())
    for h in hypotheses:
        hid = h['id']
        pair = h['matched_comparison']
        test = pair['test_variant']
        ref = pair['reference_variant']
        assert test in rows, f'{hid}: mandatory test {test} missing after Module 4'
        assert rows[test]['design_method'] == 'hypothesis_pair', (
            f'{hid}: original comparison was replaced instead of preserved'
        )
        assert test in selected_set or add(test), (
            f'{hid}: insufficient Top-k budget for mandatory test {test}'
        )
        if ref in rows:  
            assert rows[ref]['design_method'] == 'hypothesis_pair', (
                f'{hid}: mandatory reference {ref} was not preserved'
            )
            assert single_changed_position(test, ref) is not None
            assert ref in selected_set or add(ref), (
                f'{hid}: insufficient Top-k budget for mandatory control {ref}'
            )
            assigned_control_to_test.setdefault(ref, test)
            required_control_variants.add(ref)
        else:
            assert ref in measured_variants and single_changed_position(test, ref) is not None, (
                f'{hid}: mandatory reference {ref} is not a valid measured comparison'
            )
    required_controls = len(required_control_variants)
    assert required_controls <= max_controls, (
        f'{required_controls} mandatory new controls exceed configured budget {max_controls}'
    )


    for h in hypotheses:
        group = [v for v in ordered_tests if rows[v]['hypothesis_id'] == h['id']]
        group.sort(key=lambda v: (
            rows[v].get('design_method') != 'hypothesis_pair',
            facts[v]['comparison_status'] != 'measured_pair' and v not in pair_test_set,
            -priorities[v]
        ))
        if group:
            add(group[0])


    if knowledge is not None:
        kg_added = 0
        for flag in ('true', 'false'):
            options = [v for v in ordered_tests
                       if rows[v].get('design_method') == 'kg_rule_proposal'
                       and str(rows[v].get('kg_conservative', '')).lower() == flag
                       and facts[v]['comparison_status'] == 'measured_pair']
            if options and kg_added < KG_VALIDATION_SLOTS and add(options[0]):
                kg_added += 1



    new_pairs.sort(key=lambda pair: -priorities[pair[0]])
    controls_used = required_controls
    for test, ctrl in new_pairs:
        if controls_used >= max_controls:
            break
        if ctrl in selected_set or len(selected) + (test not in selected_set) + 1 > top_k:
            continue
        if test not in selected_set:
            quota = target_local if local(test) else target_other
            if n_tests(local(test)) >= quota:
                continue
            add(test)
        add(ctrl)
        assigned_control_to_test[ctrl] = test
        controls_used += 1


    for ctrl in ordered_controls:
        if controls_used >= max_controls or len(selected) == top_k:
            break
        if ctrl not in selected_set and facts[ctrl]['comparison_status'] == 'measured_pair':
            add(ctrl)
            controls_used += 1


    for is_local, target in [(True, target_local), (False, target_other)]:
        for test in ordered_tests:
            if len(selected) == top_k or n_tests(is_local) >= target:
                break
            if local(test) == is_local:
                add(test)


    for test in ordered_tests:
        if len(selected) == top_k:
            break
        add(test)

    assert len(selected) == top_k, (
        f'Only {len(selected)} valid selected experiments. '
        'Generate more test candidates in module 3; do not pad with orphan controls.'
    )

    assert all(
        h['matched_comparison']['test_variant'] in selected_set for h in hypotheses
    ), 'A hypothesis has no selected mandatory test'
    picked = df.set_index('variant').loc[selected].copy().reset_index()
    picked['selection_priority'] = picked['variant'].map(priorities)
    picked['pair_type'] = 'unpaired_exploration'
    picked['effective_reference_variant'] = ''
    picked['verified_changed_position'] = ''
    for i, row in picked.iterrows():
        variant = row['variant']
        fact = facts[variant]
        ref = fact['reference_variant']
        if variant in assigned_control_to_test:
            ref = assigned_control_to_test[variant]
            picked.at[i, 'pair_type'] = 'new_test_control_pair'
        elif any(test == variant for test in assigned_control_to_test.values()):
            ref = next(ctrl for ctrl, test in assigned_control_to_test.items() if test == variant)
            picked.at[i, 'pair_type'] = 'new_test_control_pair'
        elif fact['comparison_status'] == 'measured_pair':
            picked.at[i, 'pair_type'] = 'measured_reference_pair'
        else:
            ref = ''
        if ref:
            picked.at[i, 'effective_reference_variant'] = ref
            picked.at[i, 'verified_changed_position'] = single_changed_position(variant, ref)

    picked = picked.sort_values('predicted_fitness', ascending=False).reset_index(drop=True)
    picked = picked.drop(columns=['prediction_rank'], errors='ignore')
    picked.insert(0, 'prediction_rank', range(1, len(picked) + 1))
    selected_tests = set(picked.loc[picked['purpose'] == 'test', 'variant'])
    for _, row in picked.loc[picked['purpose'] == 'control'].iterrows():
        if row['pair_type'] == 'new_test_control_pair':
            assert row['effective_reference_variant'] in selected_tests
        else:
            assert row['pair_type'] == 'measured_reference_pair'
    assert picked['variant'].is_unique
    return picked, facts


def main():
    p = get_round_arg()
    raw_scored = pd.read_csv(p.scored)
    state = search_state(p)
    validate_candidates(p, raw_scored, state)
    hypotheses_json = json.loads(p.hypotheses.read_text(encoding='utf-8'))
    hypotheses = hypotheses_json['hypotheses']
    analysis = json.loads(p.analysis.read_text(encoding='utf-8'))
    observed = read_observed(p)
    scored = prepare_candidates(raw_scored, hypotheses)
    facts = build_pair_facts(scored, observed)


    columns = ['variant', 'hypothesis_id', 'purpose', 'reason', 'strategy',
               'anchor_variant', 'reference_variant', 'predicted_fitness', 'uncertainty']
    if 'knowledge' in analysis:
        columns += [c for c in (
            'kg_substitution', 'kg_conservative', 'kg_other_background_n',
            'kg_other_background_median_delta', 'kg_evidence_reference', 'kg_rule_ids',
        ) if c in scored.columns]
    payload = {
        'hypotheses': hypotheses,
        'candidates': scored[columns].to_dict('records'),
        'candidate_facts': list(facts.values()),
        'observed': analysis['observed'],
        'last_round': analysis['last_round'],
        'predicted_summary': {
            'count': analysis['predicted']['count'],
            'top100_site_stats': analysis['predicted']['top100_site_stats'],
            'top100_vs_pool': analysis['predicted']['top100_vs_pool'],
        },
    }
    if 'knowledge' in analysis:
        from kg_agent_knowledge import focused_knowledge
        payload['knowledge'] = focused_knowledge(analysis['knowledge'])
        payload['knowledge_selection_policy'] = (
            'KG informs hypothesis and mutation design. Fixed M0-only prediction rank, '
            'mandatory matched tests and scientific controls determine the final Top-20; '
            'no AAKG window or arbitrary pseudo-Fitness bonus.')
        payload['knowledge_design_reviews'] = {
            h['id']: h['knowledge_design'] for h in hypotheses
            if 'knowledge_design' in h
        }


    all_reviews = []
    hypothesis_assessments = None
    candidate_rows = payload['candidates']
    for offset in range(0, len(candidate_rows), REVIEW_BATCH_SIZE):
        batch_number = offset // REVIEW_BATCH_SIZE + 1
        batch_candidates = candidate_rows[offset:offset + REVIEW_BATCH_SIZE]
        batch_variants = [r['variant'] for r in batch_candidates]
        batch_payload = dict(payload)
        batch_payload['candidates'] = batch_candidates
        batch_payload['candidate_facts'] = [facts[v] for v in batch_variants]
        batch_payload['batch'] = {
            'number': batch_number,
            'total_candidates_this_batch': len(batch_candidates),
            'total_candidates_all_batches': len(candidate_rows),
        }
        if batch_number == 1:
            batch_prompt = (
                PROMPT + '\n本次只审查输入的 candidates 中的候选（不是其他批次），'
                'hypothesis_assessments 必须包含全部三条假设。'
                'reviews 中每个候选只出现一次；理由与局限分别不超过50汉字。'
            )
        else:
            batch_prompt = (
                PROMPT + '\n这不是第一批：本次只输出 '
                '{"reviews": [{"variant": "...", "hypothesis_alignment": "符合|不确定|矛盾", '
                '"scientific_reason": "...", "limitations": "..."}]}。'
                '禁止输出 hypothesis_assessments，且只审查本批 candidates。'
                'reviews 中每个候选只出现一次；理由与局限分别不超过50汉字。'
            )
        batch_review = generate_json(
            batch_prompt, batch_payload,
            debug_file=p.folder / f'invalid_critic_batch_{batch_number:02d}.txt',
        )
        batch_reviews = batch_review['reviews']
        returned_variants = [r['variant'] for r in batch_reviews]
        assert len(returned_variants) == len(batch_variants) and set(returned_variants) == set(batch_variants), (
            f'Critic batch {batch_number}: review variants differ from the requested batch'
        )
        for item in batch_reviews:
            assert all(field in item for field in
                       ('variant', 'hypothesis_alignment', 'scientific_reason', 'limitations')), (
                f'Critic batch {batch_number}: missing review fields'
            )
        all_reviews.extend(batch_reviews)
        if batch_number == 1:
            hypothesis_assessments = batch_review['hypothesis_assessments']
        print(f'Scientific Critic batch {batch_number}: reviewed '
              f'{len(batch_reviews)} / {len(candidate_rows)} candidates '
              f'(cumulative {len(all_reviews)})', flush=True)

    review = {'hypothesis_assessments': hypothesis_assessments, 'reviews': all_reviews}
    reviewed_variants = [r['variant'] for r in review['reviews']]
    assessment_ids = [r['hypothesis_id'] for r in review['hypothesis_assessments']]
    assert len(reviewed_variants) == len(scored) and set(reviewed_variants) == set(scored['variant'])
    assert len(assessment_ids) == len(hypotheses) and set(assessment_ids) == {h['id'] for h in hypotheses}

    picked, _ = select_topk(scored, observed, hypotheses, knowledge=analysis.get('knowledge'),
                          parent_variant=state['parent_variant'])
    validate_candidates(p, picked, state)
    review_fields = pd.DataFrame(review['reviews'])[
        ['variant', 'hypothesis_alignment', 'scientific_reason', 'limitations']
    ]
    picked = picked.merge(review_fields, on='variant', how='left', validate='one_to_one')
    orphaned = picked['pair_type'].eq('unpaired_exploration') & picked['reference_variant'].ne('')
    picked.loc[orphaned, 'limitations'] = (
        picked.loc[orphaned, 'limitations'].fillna('') +
        '；设计时参照序列未作为有效本轮配对入选，不得据此推断单点效应'
    )
    test_counts = Counter(picked.loc[picked['purpose'] == 'test', 'hypothesis_id'])
    picked_by_variant = picked.set_index('variant')
    for h in hypotheses:
        test = h['matched_comparison']['test_variant']
        if picked_by_variant.loc[test, 'hypothesis_id'] != h['id']:
            test_counts[h['id']] += 1
    review['selection_audit'] = {
        'n_candidates_reviewed': len(scored),
        'n_selected': len(picked),
        'n_test': int((picked['purpose'] == 'test').sum()),
        'n_control': int((picked['purpose'] == 'control').sum()),
        'n_local_test': int(((picked['purpose'] == 'test') &
                            (picked['strategy'] == 'local_optimization')).sum()),
        'n_other_test': int(((picked['purpose'] == 'test') &
                            (picked['strategy'] != 'local_optimization')).sum()),
        'hypothesis_test_counts': dict(test_counts),
        'mandatory_comparisons': {
            h['id']: h['matched_comparison'] for h in hypotheses
        },
        'pair_type_counts': dict(Counter(picked['pair_type'])),
        'policy': 'soft 10 local tests + 6 other tests + up to 4 validated controls; '
                  'each hypothesis has at least one test if candidates permit',
    }
    if 'knowledge' in analysis:
        review['selection_audit']['knowledge_source'] = analysis['knowledge']['source_graph']
        review['selection_audit']['kg_observed_pairs'] = analysis['knowledge']['observed_one_site_pairs']
        review['selection_audit']['knowledge_assisted_hypotheses_count'] = sum(
            'knowledge_design' in h for h in hypotheses)
        review['selection_audit']['kg_rule_proposals_reviewed'] = int(
            scored['design_method'].eq('kg_rule_proposal').sum())
        review['selection_audit']['kg_rule_proposals_selected'] = int(
            picked['design_method'].eq('kg_rule_proposal').sum())
        review['selection_audit']['kg_validation_slot_limit'] = KG_VALIDATION_SLOTS
        review['selection_audit']['knowledge_policy'] = (
            'KG ON reserves up to 2 of the existing Top-20 slots for one conservative and '
            'one radical KG rule proposal with a measured one-site parent. Remaining slots '
            'use M0 ranking, mandatory comparisons and normal control allocation.')
    else:
        review['selection_audit']['knowledge_policy'] = 'OFF: no GB1-KG input or rank bonus'
    p.review.write_text(json.dumps(review, ensure_ascii=False, indent=2), encoding='utf-8')
    picked.to_csv(p.topk, index=False)
    print(f'Scientific Critic: reviewed {len(scored)} candidates; selected {len(picked)}')
    print(json.dumps(review['selection_audit'], ensure_ascii=False, indent=2))
    print(f'Scientific review: {p.review}')
    print(f'Top-{len(picked)} recommendations: {p.topk}')
    print(picked[['prediction_rank', 'variant', 'hypothesis_id', 'purpose',
                  'strategy', 'pair_type', 'predicted_fitness']].to_string(index=False))


if __name__ == '__main__':
    main()
