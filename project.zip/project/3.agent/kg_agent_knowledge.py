import json
from collections import defaultdict
from functools import lru_cache
from itertools import combinations
from pathlib import Path
from statistics import median

import pandas as pd

from agent_paths import KG_DIR, read_observed

WT = 'VDGV'
POSITIONS = (39, 40, 41, 54)
AA = 'ACDEFGHIKLMNPQRSTVWY'
CONSERVATIVE_GROUPS = {
    'aliphatic': 'AVILM', 'aromatic': 'FWY', 'acidic': 'DE',
    'basic': 'KR', 'amide': 'NQ', 'hydroxyl': 'ST',
}


def single_site_change(reference, candidate):
    if len(reference) != 4 or len(candidate) != 4:
        return None
    changed = [i for i in range(4) if reference[i] != candidate[i]]
    return changed[0] if len(changed) == 1 else None


def conservative(a, b):
    return any(a in g and b in g for g in CONSERVATIVE_GROUPS.values())


def measured_pairs(observed):
    """Observed same-background comparisons; alphabetically directed, not causal globally."""
    fitness = dict(zip(observed['variant'], observed['fitness']))
    grouped = defaultdict(list)
    for v in fitness:
        for i in range(4):
            grouped[i, v[:i] + v[i+1:]].append(v)
    result = []
    for (i, background), group in grouped.items():
        for a, b in combinations(sorted(group), 2):
            result.append({
                'reference_variant': a,
                'test_variant': b,
                'position': POSITIONS[i],
                'background': background,
                'substitution': f'{a[i]}{POSITIONS[i]}{b[i]}',
                'reference_fitness': float(fitness[a]),
                'test_fitness': float(fitness[b]),
                'delta_fitness': float(fitness[b] - fitness[a]),
                'conservative': conservative(a[i], b[i]),
            })
    return pd.DataFrame(result, columns=[
        'reference_variant', 'test_variant', 'position', 'background',
        'substitution', 'reference_fitness', 'test_fitness',
        'delta_fitness', 'conservative',
    ])


def save_graph_snapshot(base, observed, pairs, folder, round_num):
    """把 KG0 与本分支迄今已测实验合并，保存为只含过去标签的图谱快照。"""
    nodes = {n['id']: n for n in base['nodes']}
    edges = list(base['edges'])
    existing_edges = {(e['source'], e['relation'], e['target']) for e in edges}

    def add_edge(source, relation, target, **attributes):
        key = (source, relation, target)
        if key not in existing_edges:
            edges.append({'source': source, 'relation': relation, 'target': target, **attributes})
            existing_edges.add(key)

    for item in observed.itertuples(index=False):
        v, fitness = str(item.variant), float(item.fitness)
        vid, oid = f'variant:{v}', f'observation:{v}'
        if vid not in nodes:
            nodes[vid] = {'id': vid, 'type': 'Variant', 'sequence': v,
                          'mutations_from_wt': sum(a != b for a, b in zip(WT, v)),
                          'measured': True}
        if oid not in nodes:
            nodes[oid] = {'id': oid, 'type': 'FitnessObservation', 'fitness': fitness,
                          'evidence': 'known_experiment_prior_to_target_round'}
        add_edge(vid, 'has_observation', oid)
        for i, (old, new) in enumerate(zip(WT, v)):
            if old == new:
                continue
            pos = POSITIONS[i]
            name = f'{old}{pos}{new}'
            mid = f'mutation:{name}'
            if mid not in nodes:
                nodes[mid] = {'id': mid, 'type': 'Mutation', 'name': name,
                              'position': pos, 'from_aa': old, 'to_aa': new,
                              'conservative': conservative(old, new)}
            add_edge(vid, 'contains_mutation', mid)
            add_edge(mid, 'occurs_at', f'position:{pos}')
            add_edge(mid, 'changes_from', f'aa:{old}')
            add_edge(mid, 'changes_to', f'aa:{new}')

    for pair in pairs.itertuples(index=False):
        a, b = pair.reference_variant, pair.test_variant
        cid = f'comparison:{a}:{b}'
        if cid not in nodes:
            nodes[cid] = {'id': cid, 'type': 'MeasuredSingleSiteComparison',
                          'reference_variant': a, 'test_variant': b,
                          'position': int(pair.position), 'background': pair.background,
                          'substitution': pair.substitution,
                          'delta_fitness': float(pair.delta_fitness),
                          'reference_fitness': float(pair.reference_fitness),
                          'test_fitness': float(pair.test_fitness),
                          'evidence': 'observed_fitness_difference_not_global_mutation_effect'}
        add_edge(f'variant:{a}', 'comparison_reference', cid)
        add_edge(cid, 'comparison_test', f'variant:{b}')

    snapshot = {**{k: v for k, v in base.items() if k not in ('nodes', 'edges')},
                'snapshot_for_round': round_num, 'observed_count': len(observed),
                'nodes': list(nodes.values()), 'edges': edges}
    path = folder / 'kg_graph_snapshot.json'
    path.write_text(json.dumps(snapshot, ensure_ascii=False), encoding='utf-8')
    return path


def build_knowledge(paths):
    """Load static KG0 from user-built files; update measured pair index from past rounds."""
    graph_path = KG_DIR / 'kg_graph.json'
    pair_source = KG_DIR / 'kg_measured_pairs.csv'
    if graph_path.exists():
        graph = json.loads(graph_path.read_text(encoding='utf-8'))
        base_pair_count = len(pd.read_csv(pair_source))
    else:
        # Also support the project graph exported by 6.knowledge's M0 builder.
        graph_path = KG_DIR / 'output/m0_496/graph.json'
        source = json.loads(graph_path.read_text(encoding='utf-8'))
        graph = {**source, 'nodes': [{**node, **node.get('properties', {})} for node in source['nodes']]}
        for node in graph['nodes']:
            if node['type'] == 'AminoAcid':
                node.update(symbol=node['code'], polarity=node['polarity_class'],
                            charge=node['charge_class_imgt'], size=node['size_class'],
                            hydropathy=node['hydropathy_kd'])
        graph['rules'] = {
            'R1': 'Only canonical four-residue variants are legal',
            'R2': 'Positions are 39,40,41,54; compare one changed site',
            'R3': 'New variants stay one mutation from the current seeded parent',
            'R4': 'Physicochemical properties are not measured fitness',
            'R5': 'Historical contrasts are background-dependent',
            'R6': 'Exclude previously measured and held-out variants',
            'R7': 'Parents belong to the seed trajectory, not the global elite archive',
        }
        base_pair_count = int(source['metadata']['undirected_single_site_pairs'])
        pair_source = graph_path  # Pair counts are supplied by this graph's metadata.
    known = read_observed(paths)
    pairs = measured_pairs(known)
    paths.folder.mkdir(parents=True, exist_ok=True)
    pair_path = paths.folder / 'kg_observed_pairs.csv'
    pairs.to_csv(pair_path, index=False)
    load_pairs.cache_clear()
    snapshot_path = save_graph_snapshot(graph, known, pairs, paths.folder, paths.round_num)

    aa = {}
    for n in graph['nodes']:
        if n['type'] == 'AminoAcid':
            aa[n['symbol']] = {
                'polarity': n['polarity'], 'charge': n['charge'],
                'size': n['size'], 'hydropathy': float(n['hydropathy'])
            }
    # For the first round, the graph and the observed data describe the same 496 labels.
    ordered = pairs.sort_values('delta_fitness')
    def examples(df):
        return df[[
            'reference_variant', 'test_variant', 'position',
            'substitution', 'delta_fitness'
        ]].round(4).to_dict('records')
    return {
        'type': 'GB1_own_measured_fitness_knowledge_graph',
        'source_graph': str(graph_path),
        'graph_snapshot': str(snapshot_path),
        'm0_history_variants': len(pd.read_csv(paths.m0_history, usecols=['variant'])),
        'source_pairs': str(pair_source),
        'target_round': paths.round_num,
        'base_graph_pairs': base_pair_count,
        'observed_variant_count': len(known),
        'observed_one_site_pairs': len(pairs),
        'rules': graph['rules'],
        'amino_acids': aa,
        'conservative_groups_heuristic': CONSERVATIVE_GROUPS,
        'largest_measured_positive_pairs': examples(ordered.tail(10).iloc[::-1]),
        'largest_measured_negative_pairs': examples(ordered.head(10)),
        'evidence_policy': ('Only earlier measured labels may enter the graph. '
                            'A historical single-site fitness change is background-dependent; '
                            'it is NOT a global beneficial-mutation rule. '
                            'Predicted fitness is never a verified KG observation.'),
    }


@lru_cache(maxsize=8)
def load_pairs(path):
    return pd.read_csv(path).to_dict('records')


def evaluate_substitution(knowledge, paths, reference, candidate, max_examples=2):
    """Annotate a proposed one-site replacement with real KG properties and analog evidence."""
    reference = str(reference).upper().strip()
    candidate = str(candidate).upper().strip()
    idx = single_site_change(reference, candidate)
    if idx is None:
        return None
    old, new = reference[idx], candidate[idx]
    p = knowledge['amino_acids']
    position = POSITIONS[idx]
    context = reference[:idx] + reference[idx+1:]
    history = []
    path = str(paths.folder / 'kg_observed_pairs.csv')
    for pair in load_pairs(path):
        if int(pair['position']) != position or str(pair['background']) == context:
            continue
        a, b = str(pair['reference_variant']), str(pair['test_variant'])
        if a[idx] == old and b[idx] == new:
            delta = float(pair['delta_fitness'])
        elif a[idx] == new and b[idx] == old:
            delta = -float(pair['delta_fitness'])
        else:
            continue
        history.append({
            'variant_a': a, 'variant_b': b,
            'other_background': pair['background'],
            'delta_in_proposed_direction': round(delta, 5),
        })
    deltas = [r['delta_in_proposed_direction'] for r in history]
    return {
        'reference_variant': reference,
        'test_variant': candidate,
        'changed_position': position,
        'substitution': f'{old}{position}{new}',
        'knowledge_rules': ['R2', 'R3', 'R4', 'R5'],
        'conservative_heuristic': conservative(old, new),
        'polarity_from': p[old]['polarity'], 'polarity_to': p[new]['polarity'],
        'charge_from': p[old]['charge'], 'charge_to': p[new]['charge'],
        'size_from': p[old]['size'], 'size_to': p[new]['size'],
        'delta_hydropathy': round(p[new]['hydropathy'] - p[old]['hydropathy'], 3),
        'other_background_n': len(history),
        'other_background_median_delta': round(median(deltas), 5) if deltas else None,
        'other_background_positive_fraction': round(sum(x > 0 for x in deltas) / len(deltas), 3) if deltas else None,
        'other_background_examples': sorted(
            history, key=lambda r: -abs(r['delta_in_proposed_direction']))[:max_examples],
        'evidence_scope': 'KG0_or_earlier_rounds_chemical_and_other_background_data',
        'is_candidate_fitness_known': False,
    }


def knowledge_suggestions(anchor, eligible, scores, knowledge, paths, limit=8):
    """A diverse, *testable* KG candidate shortlist, no pseudo-Fitness addition."""
    options = []
    for i in range(4):
        for new in AA:
            if new == anchor[i]:
                continue
            v = anchor[:i] + new + anchor[i+1:]
            if v not in eligible:
                continue
            evidence = evaluate_substitution(knowledge, paths, anchor, v, max_examples=2)
            options.append({'variant': v, 'predicted_fitness': float(scores[v]),
                            'changed_position': POSITIONS[i], 'evidence': evidence})
    chosen = []
    present = set()
    def keep(item):
        if item['variant'] not in present and len(chosen) < limit:
            chosen.append(item)
            present.add(item['variant'])
    # Explicitly present conservative and radical chemistry as scientific contrasts.
    for flag in (True, False):
        subset = [x for x in options if x['evidence']['conservative_heuristic'] == flag]
        if subset:
            keep(max(subset, key=lambda x: (x['predicted_fitness'], x['variant'])))
    # Query observed cross-background contrasts; these are hypotheses, not known benefits.
    supported = [x for x in options if x['evidence']['other_background_n'] >= 2]
    for x in sorted(supported, key=lambda r: (
            -(r['evidence']['other_background_median_delta'] or 0),
            -r['predicted_fitness'], r['variant'])):
        keep(x)
    for x in sorted(options, key=lambda r: (-r['predicted_fitness'], r['variant'])):
        keep(x)
    return chosen


def knowledge_pairs(anchors, eligible, scores, knowledge, paths, existing, per_anchor=5):
    keys = {(p['test_variant'], p['reference_variant']) for p in existing}
    result = []
    for anchor in anchors:
        added = 0
        for row in knowledge_suggestions(anchor, eligible, scores, knowledge, paths, limit=12):
            v = row['variant']
            if (v, anchor) in keys:
                continue
            result.append({
                'test_variant': v, 'reference_variant': anchor,
                'changed_position': row['changed_position'],
                'reference_role': 'measured_reference',
                'selection_basis': 'kg_chemistry_and_measured_pair_query',
                'knowledge_evidence': row['evidence'],
            })
            keys.add((v, anchor))
            added += 1
            if added >= per_anchor:
                break
    return result


def focused_knowledge(knowledge, max_pairs=5):
    return {
        'type': knowledge['type'],
        'target_round': knowledge['target_round'],
        'rules': knowledge['rules'],
        'conservative_groups_heuristic': knowledge['conservative_groups_heuristic'],
        'observed_variant_count': knowledge['observed_variant_count'],
        'observed_one_site_pairs': knowledge['observed_one_site_pairs'],
        'largest_measured_positive_pairs': knowledge['largest_measured_positive_pairs'][:max_pairs],
        'largest_measured_negative_pairs': knowledge['largest_measured_negative_pairs'][:max_pairs],
        'evidence_policy': knowledge['evidence_policy'],
    }
