"""VER4.3: Random Search and frozen M0-AL direct ranking baselines.

Place under ver4.3/5.test/1.baseline. Both methods share exactly the Agent's independent
initial experiment file and eligible pool. Fitness is revealed by the offline
Oracle only AFTER the selection is fixed. Neither branch reads Agent rounds.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys

# Folder layout: ver4.3/5.test/1.baseline/<this_script>.py
# Reuse paths from ver4.3/3.agent/agent_paths.py without moving any model/data files.
AGENT_CODE_DIR = Path(__file__).resolve().parents[2] / "3.agent"
sys.path.insert(0, str(AGENT_CODE_DIR))

import numpy as np
import pandas as pd

from agent_paths import (
    AGENT_RESULT_DIR, AGENT_INITIAL_FILE, INITIAL_FILE, ORACLE_FILE,
    POOL_PREDICTIONS, TEST_FILE,
)

WT = 'VDGV'
AA = set('ACDEFGHIKLMNPQRSTVWY')


def normalize_variant(s):
    return s.astype(str).str.upper().str.strip()


def fingerprint(frame):
    """Fingerprint the actual initial labels; used to reject resumed data drift."""
    parts = [f'{v},{float(f):.12g}' for v, f in
             sorted(zip(frame['variant'], frame['fitness']))]
    return hashlib.sha256('\n'.join(parts).encode('utf-8')).hexdigest()


def load_inputs():
    if not AGENT_INITIAL_FILE.exists():
        raise FileNotFoundError(
            f'Missing Agent initial experiments: {AGENT_INITIAL_FILE}. '
            'Run python 0.initialize_agent_experiments.py once before baselines.'
        )

    initial = pd.read_csv(AGENT_INITIAL_FILE, usecols=['variant', 'fitness'])
    initial['variant'] = normalize_variant(initial['variant'])
    assert initial['variant'].is_unique, 'Initial set has duplicate variants'
    assert initial['fitness'].notna().all(), 'Initial set has missing fitness labels'

    m0_training = pd.read_csv(INITIAL_FILE, usecols=['variant'])
    heldout = pd.read_csv(TEST_FILE, usecols=['variant'])
    training_ids = set(normalize_variant(m0_training['variant']))
    test_ids = set(normalize_variant(heldout['variant']))
    initial_ids = set(initial['variant'])
    assert not initial_ids & (training_ids | test_ids), 'Initial set overlaps M0 train or FLIP test'

    pool = pd.read_csv(POOL_PREDICTIONS,
                       usecols=['variant', 'predicted_fitness', 'uncertainty'])
    pool['variant'] = normalize_variant(pool['variant'])
    assert pool['variant'].is_unique, 'Duplicate variant in M0 prediction pool'
    assert pool['predicted_fitness'].notna().all(), 'Missing M0 predictions'
    assert pool['uncertainty'].notna().all(), 'Missing M0 uncertainty'
    assert pool['variant'].map(lambda v: len(v) == 4 and set(v) <= AA).all(), 'Invalid GB1 variant'

    # This eligible set is identical for both baselines; no fitness labels from
    # M0 training or held-out test data are ever used for candidate selection.
    excluded = training_ids | test_ids | initial_ids
    pool = pool.loc[~pool['variant'].isin(excluded)].copy()
    assert len(pool) > 0, 'Eligible candidate pool is empty'

    # Fixed global M0 order. Stable ties are resolved alphabetically.
    pool = pool.sort_values(['predicted_fitness', 'variant'],
                            ascending=[False, True], kind='mergesort').reset_index(drop=True)
    pool['global_m0_rank'] = np.arange(1, len(pool) + 1)
    return initial, pool, training_ids, test_ids


def branch_dir(method, seed, run_tag):
    suffix = f'_{run_tag}' if run_tag else ''
    branch = f'random_search_seed{seed}{suffix}' if method == 'random' else f'm0_only{suffix}'
    return AGENT_RESULT_DIR / 'baselines' / branch


def choose_variants(method, eligible, top_k, seed, round_num):
    """Selection never consumes true fitness labels."""
    assert len(eligible) >= top_k, f'Only {len(eligible)} candidates left for {top_k} slots'
    if method == 'm0':
        return eligible.head(top_k).copy()
    # Every round uses a deterministic independent RNG, making restart possible.
    rng = np.random.default_rng(np.random.SeedSequence([seed, round_num]))
    ids = rng.choice(eligible['variant'].to_numpy(), size=top_k, replace=False)
    return eligible.set_index('variant').loc[ids].reset_index()


def query_offline_oracle(selected):
    """Read oracle only after the sequence selection has been committed."""
    oracle = pd.read_csv(ORACLE_FILE, usecols=['AACombo', 'Fitness'])
    oracle = oracle.rename(columns={'AACombo': 'variant', 'Fitness': 'fitness'})
    oracle['variant'] = normalize_variant(oracle['variant'])
    assert oracle['variant'].is_unique, 'Duplicate variants in GB1 oracle'
    result = selected.merge(oracle, on='variant', how='left', validate='one_to_one', sort=False)
    assert result['fitness'].notna().all(), 'The offline Oracle has no label for some selected variants'
    result['prediction_error'] = result['predicted_fitness'] - result['fitness']
    result['purpose'] = 'test'
    result['n_mutations_vs_wt'] = [sum(a != b for a, b in zip(v, WT))
                                    for v in result['variant']]
    return result


def create_summary(branch, initial, method, last_round, top_k):
    rows = []
    previous_best = None
    previous_mean = None
    best_so_far = float(initial['fitness'].max())
    for r in range(1, last_round + 1):
        data = pd.read_csv(branch / f'round_{r:03d}' / 'experiment_results.csv')
        assert len(data) == top_k, f'Round {r}: expected {top_k} measured variants'
        best = float(data['fitness'].max())
        mean = float(data['fitness'].mean())
        best_so_far = max(best_so_far, best)
        rows.append({
            'round': r,
            'model': 'M0-AL',
            'knowledge_mode': 'not_applicable',
            'method': 'Random Search' if method == 'random' else 'M0-AL Only',
            'n_measured': len(data),
            'round_best_fitness': best,
            'round_mean_fitness': mean,
            'round_median_fitness': float(data['fitness'].median()),
            'agent_best_so_far': best_so_far,  # Agent-compatible cumulative-best column name
            'initial_agent_best_fitness': float(initial['fitness'].max()),
            'delta_best_vs_previous_round': (best - previous_best if previous_best is not None else float('nan')),
            'delta_mean_vs_previous_round': (mean - previous_mean if previous_mean is not None else float('nan')),
            'count_above_wt': int((data['fitness'] > 1.0).sum()),
            'n_test': len(data),
            'n_control': 0,
            'cumulative_new_experiments': r * top_k,
            'cumulative_total_experiments': len(initial) + r * top_k,
        })
        previous_best, previous_mean = best, mean
    summary = pd.DataFrame(rows)
    summary.to_csv(branch / 'evolution_summary.csv', index=False)
    return summary


def run_method(method, args, initial, pool, train_ids, heldout_ids):
    branch = branch_dir(method, args.seed, args.run_tag)
    branch.mkdir(parents=True, exist_ok=True)
    meta_path = branch / 'baseline_metadata.json'
    meta = {
        'baseline': method,
        'initial_source': str(AGENT_INITIAL_FILE),
        'initial_count': len(initial),
        'initial_fingerprint_sha256': fingerprint(initial),
        'pool_source': str(POOL_PREDICTIONS),
        'oracle_source': str(ORACLE_FILE),
        'heldout_source': str(TEST_FILE),
        'model_training_ids_source': str(INITIAL_FILE),
        'top_k': args.top_k,
        'random_seed': args.seed if method == 'random' else None,
        'selection_rule': (
            'uniform_without_replacement_from_remaining_eligible_pool' if method == 'random'
            else 'frozen_M0_predictions_descending_global_greedy'
        ),
        'oracle_access': 'selected_variants_only_after_selection',
        'model_updated': False,
    }
    if meta_path.exists():
        previous = json.loads(meta_path.read_text(encoding='utf-8'))
        assert previous == meta, f'Metadata changed for {branch}; use a new --run-tag'
    else:
        # No existing run may be silently adopted without provenance.
        assert not list(branch.glob('round_*')), f'Existing rounds but missing metadata: {branch}'
        meta_path.write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding='utf-8')

    initial_ids = set(initial['variant'])
    used = set(initial_ids)
    for earlier in range(1, args.start_round):
        path = branch / f'round_{earlier:03d}' / 'experiment_results.csv'
        if not path.exists():
            raise FileNotFoundError(f'Cannot resume: missing completed Round {earlier}: {path}')
        previous = pd.read_csv(path, usecols=['variant'])
        ids = set(normalize_variant(previous['variant']))
        assert len(ids) == args.top_k and not used & ids, f'Invalid previous Round {earlier}: {path}'
        used.update(ids)

    for r in range(args.start_round, args.start_round + args.rounds):
        folder = branch / f'round_{r:03d}'
        if folder.exists():
            raise FileExistsError(f'Refusing to overwrite existing/partial round: {folder}')
        eligible = pool.loc[~pool['variant'].isin(used)]
        selected = choose_variants(method, eligible, args.top_k, args.seed, r)
        ids = set(selected['variant'])
        assert len(selected) == len(ids) == args.top_k
        assert not ids & (used | train_ids | heldout_ids)
        selected = selected.copy()
        selected.insert(0, 'selection_rank', range(1, args.top_k + 1))
        selected['selection_policy'] = meta['selection_rule']

        # Lock in selected IDs on disk before any ground truth becomes visible.
        folder.mkdir(parents=True)
        selected.to_csv(folder / 'selected_candidates.csv', index=False)
        result = query_offline_oracle(selected)
        result.to_csv(folder / 'experiment_results.csv', index=False)
        used.update(ids)
        summary = create_summary(branch, initial, method, r, args.top_k)
        print(f'{method} Round {r:02d}: best={result.fitness.max():.6f} '
              f'mean={result.fitness.mean():.6f} '
              f'best_so_far={summary.iloc[-1]["agent_best_so_far"]:.6f} '
              f'-> {folder}', flush=True)
    print(f'{method} complete: {branch / "evolution_summary.csv"}', flush=True)


def main():
    parser = argparse.ArgumentParser(description='VER4.3 fair Random and M0-only baselines')
    parser.add_argument('--method', choices=['both', 'random', 'm0'], default='both')
    parser.add_argument('--start-round', type=int, default=1)
    parser.add_argument('--rounds', type=int, default=3)
    parser.add_argument('--top-k', type=int, default=20)
    parser.add_argument('--seed', type=int, default=114514,
                        help='Random Search seed, distinct from Agent initial selection')
    parser.add_argument('--run-tag', type=str, default='',
                        help='Optional suffix for an isolated experiment directory')
    args = parser.parse_args()
    assert args.start_round >= 1 and args.rounds >= 1 and args.top_k >= 1
    assert args.seed >= 0
    assert not args.run_tag or (args.run_tag.replace('-', '').replace('_', '').isalnum()), \
        '--run-tag must use only letters, digits, underscore or dash'
    initial, pool, training, heldout = load_inputs()
    print(f'Initial={len(initial)}, eligible pool={len(pool)}, '
          f'init_best={initial.fitness.max():.6f}; '
          'the original Agent rounds will not be touched.', flush=True)
    methods = ['random', 'm0'] if args.method == 'both' else [args.method]
    for method in methods:
        run_method(method, args, initial, pool, training, heldout)


if __name__ == '__main__':
    main()
