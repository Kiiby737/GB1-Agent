
"""Compare four GB1 evolution methods and export vector PDF."""

import argparse
from pathlib import Path
import sys

AGENT_CODE_DIR = Path(__file__).resolve().parents[2] / "3.agent"
sys.path.insert(0, str(AGENT_CODE_DIR))

import pandas as pd
import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt

from agent_paths import (
    AGENT_RESULT_DIR,
    BASE_ROUNDS_DIR,
    KG_ROUNDS_DIR,
)


def load_summary(
    name,
    path,
    rounds,
    expected_per_round,
    expected_initial_best
):
    if not path.exists():
        raise FileNotFoundError(
            f"{name}: summary file not found: {path}"
        )

    df = pd.read_csv(path).sort_values("round")
    df = df[df["round"] <= rounds].copy()

    if list(df["round"]) != list(range(1, rounds + 1)):
        raise ValueError(f"{name}: missing rounds")

    if not (df["n_measured"] == expected_per_round).all():
        raise ValueError(f"{name}: unequal per-round budgets")

    # Agent ON/OFF summaries may not contain this column.
    if "initial_agent_best_fitness" not in df.columns:
        if name in ("LLM Agent ON", "LLM Agent OFF"):
            df["initial_agent_best_fitness"] = expected_initial_best
        else:
            raise ValueError(
                f"{name}: missing initial_agent_best_fitness"
            )

    if not (
        df["initial_agent_best_fitness"]
        .sub(expected_initial_best)
        .abs()
        .lt(1e-8)
    ).all():
        raise ValueError(
            f"{name}: initial best Fitness differs"
        )

    required_columns = [
        "round_best_fitness",
        "round_mean_fitness",
        "agent_best_so_far",
        "count_above_wt",
    ]

    missing = set(required_columns) - set(df.columns)

    if missing:
        raise ValueError(
            f"{name}: missing columns {sorted(missing)}"
        )

    df["method"] = name
    df["cumulative_new_experiments"] = (
        df["round"] * expected_per_round
    )

    return df


def create_summary(table, initial, output):
    totals = []

    for name, group in table.groupby("method", sort=False):
        group = group.sort_values("round")
        last = group.iloc[-1]

        n = int(group["n_measured"].sum())

        totals.append({
            "method": name,
            "rounds": len(group),
            "initial_n": len(initial),
            "new_experiments": n,
            "total_labels_including_initial": len(initial) + n,
            "cumulative_best_fitness": float(
                last["agent_best_so_far"]
            ),
            "best_round_fitness": float(
                group["round_best_fitness"].max()
            ),
            "all_rounds_mean_fitness": float(
                (
                    group["round_mean_fitness"]
                    * group["n_measured"]
                ).sum() / n
            ),
            "above_wt_fraction": float(
                group["count_above_wt"].sum() / n
            ),
        })

    summary = pd.DataFrame(totals)

    summary.to_csv(
        output / "four_method_summary.csv",
        index=False
    )

    return summary


def plot_comparison(table, rounds, output):

    # Editable TrueType fonts in PDF.
    plt.rcParams["pdf.fonttype"] = 42
    plt.rcParams["ps.fonttype"] = 42
    plt.rcParams["font.family"] = "DejaVu Sans"
    plt.rcParams["axes.unicode_minus"] = False

    method_order = [
        "Random Search",
        "M0-AL Only",
        "LLM Agent OFF",
        "LLM Agent ON",
    ]

    metrics = [
        "round_best_fitness",
        "round_mean_fitness",
    ]

    titles = [
        "(A) Best Fitness",
        "(B) Mean Fitness",
    ]

    ylabels = [
        "Best Fitness",
        "Mean Fitness",
    ]

    fig, axes = plt.subplots(
        1,
        2,
        figsize=(12, 5),
        sharex=True
    )

    for ax, metric, title, ylabel in zip(
        axes, metrics, titles, ylabels
    ):

        for name in method_order:

            group = table[
                table["method"] == name
            ].sort_values("round")

            ax.plot(
                group["round"],
                group[metric],
                marker="o",
                markersize=6,
                linewidth=1.8,
                label=name
            )

        ax.set_title(
            title,
            fontsize=13,
            fontweight="bold"
        )

        ax.set_xlabel(
            "Evolution Round",
            fontsize=11
        )

        ax.set_ylabel(
            ylabel,
            fontsize=11
        )

        ax.set_xticks(range(1, rounds + 1))

        ax.grid(
            axis="y",
            linestyle="--",
            alpha=0.35
        )

        ax.tick_params(
            axis="both",
            labelsize=10
        )

        ax.legend(
            fontsize=9,
            frameon=False
        )

    fig.suptitle(
        "GB1 Directed Evolution: Four-Method Comparison",
        fontsize=14,
        fontweight="bold"
    )

    fig.tight_layout(
        rect=[0, 0, 1, 0.93]
    )

    pdf_path = output / "four_method_comparison.pdf"

    fig.savefig(
        pdf_path,
        format="pdf",
        bbox_inches="tight"
    )

    plt.close(fig)

    return pdf_path


def main():

    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--rounds",
        type=int,
        default=3
    )

    parser.add_argument(
        "--top-k",
        type=int,
        default=20
    )

    parser.add_argument(
        "--seed",
        type=int,
        default=114514
    )

    parser.add_argument(
        "--run-tag",
        default=""
    )

    args = parser.parse_args()

    if args.rounds < 1 or args.top_k < 1:
        raise ValueError("rounds and top-k must be positive")

    # Shared initial experiment data.
    initial = pd.read_csv(
        AGENT_RESULT_DIR / "agent_initial_labeled.csv"
    )

    initial_best = float(
        initial["fitness"].max()
    )

    suffix = f"_{args.run_tag}" if args.run_tag else ""

    base = AGENT_RESULT_DIR / "baselines"

    # Four experiment groups.
    sources = [
        (
            "Random Search",
            base / (
                f"random_search_seed{args.seed}{suffix}"
            ) / "evolution_summary.csv"
        ),
        (
            "M0-AL Only",
            base / f"m0_only{suffix}" / "evolution_summary.csv"
        ),
        (
            "LLM Agent OFF",
            BASE_ROUNDS_DIR / "evolution_summary.csv"
        ),
        (
            "LLM Agent ON",
            KG_ROUNDS_DIR / "evolution_summary.csv"
        ),
    ]

    records = []

    for name, path in sources:

        df = load_summary(
            name,
            path,
            args.rounds,
            args.top_k,
            initial_best
        )

        records.append(df)

        print(
            f"{name}: loaded {len(df)} rounds"
        )

    # Combine four methods.
    table = pd.concat(
        records,
        ignore_index=True
    )

    output = base / "comparison"
    output.mkdir(
        parents=True,
        exist_ok=True
    )

    # Save per-round results.
    table.to_csv(
        output / "four_method_per_round.csv",
        index=False
    )

    # Save overall summary.
    summary = create_summary(
        table,
        initial,
        output
    )

    # Generate vector PDF.
    pdf_path = plot_comparison(
        table,
        args.rounds,
        output
    )

    print("\n" + "=" * 65)
    print("Four-method comparison completed")
    print("=" * 65)

    print("\nPDF:")
    print(pdf_path)

    print("\nPer-round CSV:")
    print(output / "four_method_per_round.csv")

    print("\nSummary CSV:")
    print(output / "four_method_summary.csv")

    print("\nOverall comparison:")
    print(
        summary.to_string(index=False)
    )


if __name__ == "__main__":
    main()
