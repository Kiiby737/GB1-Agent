import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import spearmanr

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / '3.agent'))
from agent_paths import MODEL_FILE, ORACLE_FILE, TEST_FILE

OUT_DIR = Path(__file__).resolve().parent / 'm0_al_independent_test'
ESM_NAME = 'esm2_t33_650M_UR50D'
POSITIONS = (39, 40, 41, 54)


def predict_m0(test, sequences_file, batch_size):
    import torch
    import esm

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    sequences = test.merge(sequences_file, on='variant')

    esm_model, alphabet = esm.pretrained.load_model_and_alphabet(ESM_NAME)
    esm_model = esm_model.to(device).eval()
    converter = alphabet.get_batch_converter()
    features = []

    with torch.inference_mode():
        for start in range(0, len(sequences), batch_size):
            batch = sequences.iloc[start:start + batch_size]
            _, _, tokens = converter(list(zip(batch['variant'], batch['seq'])))
            reps = esm_model(tokens.to(device), repr_layers=[esm_model.num_layers],
                             return_contacts=False)['representations'][esm_model.num_layers]
            features.append(reps[:, POSITIONS, :].reshape(len(batch), -1).cpu())
            print(f'ESM2: {min(start + batch_size, len(sequences))}/{len(sequences)}', flush=True)

    del esm_model
    features = torch.cat(features).to(device)

    class MLP(torch.nn.Module):
        def __init__(self, input_dim, hidden_dim, dropout):
            super().__init__()
            self.net = torch.nn.Sequential(
                torch.nn.Linear(input_dim, hidden_dim),
                torch.nn.ReLU(),
                torch.nn.Dropout(dropout),
                torch.nn.Linear(hidden_dim, 1),
            )

        def forward(self, x):
            return self.net(x).squeeze(-1)

    checkpoint = torch.load(MODEL_FILE, map_location='cpu', weights_only=False)
    x = (features - checkpoint['feature_mean'].to(device)) / checkpoint['feature_scale'].to(device)
    member_predictions = []

    with torch.inference_mode():
        for member in checkpoint['ensemble']:
            model = MLP(checkpoint['input_dim'], checkpoint['hidden_dim'], checkpoint['dropout']).to(device)
            model.load_state_dict(member['model_state_dict'])
            model.eval()
            y = model(x).cpu().numpy() * member['fitness_std'] + member['fitness_mean']
            member_predictions.append(y)

    return pd.DataFrame({
        'variant': sequences['variant'],
        'predicted_fitness': np.mean(member_predictions, axis=0),
    })


def evaluate(result):
    y = result['fitness'].to_numpy(dtype=float)
    yhat = result['predicted_fitness'].to_numpy(dtype=float)
    mse = float(np.mean((y - yhat) ** 2))
    metrics = {
        'n_test': len(result),
        'pearson': float(np.corrcoef(y, yhat)[0, 1]),
        'spearman': float(spearmanr(y, yhat).statistic),
        'mse': mse,
        'rmse': float(np.sqrt(mse)),
    }

    predicted_rank = result.sort_values(['predicted_fitness', 'variant'], ascending=[False, True])
    true_rank = result.sort_values(['fitness', 'variant'], ascending=[False, True])
    topk = []
    for k in (5, 10):
        n = len(set(predicted_rank['variant'].head(k)) & set(true_rank['variant'].head(k)))
        topk.append({'k': k, 'topk_overlap_count': n, 'topk_overlap_rate': n / k})
    return metrics, pd.DataFrame(topk)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--predictions', type=Path, default=None,
                        help='Existing independent-test predictions CSV; skip ESM2 inference')
    parser.add_argument('--esm-batch-size', type=int, default=4)
    args = parser.parse_args()

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    test = pd.read_csv(TEST_FILE, usecols=['variant'])

    if args.predictions:
        predictions = pd.read_csv(args.predictions, usecols=['variant', 'predicted_fitness'])
    else:
        sequences = pd.read_csv(ORACLE_FILE, usecols=['AACombo', 'seq']).rename(
            columns={'AACombo': 'variant'}
        )
        predictions = predict_m0(test, sequences, args.esm_batch_size)

    labels = pd.read_csv(ORACLE_FILE, usecols=['AACombo', 'Fitness']).rename(
        columns={'AACombo': 'variant', 'Fitness': 'fitness'}
    )
    result = test.merge(predictions, on='variant').merge(labels, on='variant')
    metrics, topk = evaluate(result)

    result.to_csv(OUT_DIR / 'm0_al_test_predictions_with_labels.csv', index=False)
    topk.to_csv(OUT_DIR / 'm0_al_test_topk_metrics.csv', index=False)
    (OUT_DIR / 'm0_al_test_metrics.json').write_text(
        json.dumps({**metrics, 'topk': topk.to_dict('records')}, indent=2), encoding='utf-8'
    )

    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(6.2, 5.2))
    ax.scatter(result['fitness'], result['predicted_fitness'], s=12, alpha=0.35)
    lo = min(result['fitness'].min(), result['predicted_fitness'].min())
    hi = max(result['fitness'].max(), result['predicted_fitness'].max())
    ax.plot([lo, hi], [lo, hi], '--', linewidth=1)
    ax.set(xlabel='True Fitness', ylabel='Predicted Fitness', title='M0-AL Independent Test')
    fig.tight_layout()
    fig.savefig(OUT_DIR / 'm0_al_test_scatter.png', dpi=180)
    plt.close(fig)

    print(json.dumps({**metrics, 'topk': topk.to_dict('records')}, indent=2))
    print(f'Output: {OUT_DIR}')


if __name__ == '__main__':
    main()
