#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
from collections import Counter, defaultdict
from itertools import combinations
from pathlib import Path

import pandas as pd

ROOT = Path('<PROJECT_ROOT>')
INPUT_CSV = ROOT / '2.train/hybrid_30_40_30_r9/M0_AL_labeled.csv'
OUT = ROOT / '6.knowledge'

WT = 'VDGV'
POSITIONS = (39, 40, 41, 54)


AA = {
    'A': ('nonpolar', 'neutral', 'small', 1.8),
    'C': ('polar', 'neutral', 'small', 2.5),
    'D': ('polar', 'negative', 'medium', -3.5),
    'E': ('polar', 'negative', 'medium', -3.5),
    'F': ('nonpolar', 'neutral', 'large', 2.8),
    'G': ('nonpolar', 'neutral', 'small', -0.4),
    'H': ('polar', 'pH_dependent', 'medium', -3.2),
    'I': ('nonpolar', 'neutral', 'medium', 4.5),
    'K': ('polar', 'positive', 'large', -3.9),
    'L': ('nonpolar', 'neutral', 'medium', 3.8),
    'M': ('nonpolar', 'neutral', 'medium', 1.9),
    'N': ('polar', 'neutral', 'medium', -3.5),
    'P': ('nonpolar', 'neutral', 'small', -1.6),
    'Q': ('polar', 'neutral', 'medium', -3.5),
    'R': ('polar', 'positive', 'large', -4.5),
    'S': ('polar', 'neutral', 'small', -0.8),
    'T': ('polar', 'neutral', 'small', -0.7),
    'V': ('nonpolar', 'neutral', 'small', 4.2),
    'W': ('nonpolar', 'neutral', 'large', -0.9),
    'Y': ('polar', 'neutral', 'large', -1.3),
}

CONSERVATIVE_GROUPS = {
    'aliphatic': 'AVILM', 'aromatic': 'FWY', 'acidic': 'DE',
    'basic': 'KR', 'amide': 'NQ', 'hydroxyl': 'ST',
}
RULES = {
    'R1': 'Only 20 canonical amino acids are allowed at each GB1 site.',
    'R2': 'Prefer one-site changes relative to an already measured parent.',
    'R3': 'Use conservative versus radical substitutions as contrasting hypotheses.',
    'R4': 'A beneficial substitution is supported only in its measured sequence background.',
    'R5': 'Combining beneficial substitutions requires new measurements because of epistasis.',
    'R6': 'Count mutations relative to WT separately from changes relative to a parent.',
    'R7': 'Protein-level 4-AA variants cannot contain a stop codon; DNA design needs codon checks.',
}

nodes = {}
edges = []

def node(node_id, node_type, **attrs):
    nodes[node_id] = {'id': node_id, 'type': node_type, **attrs}

def edge(source, relation, target, **attrs):
    edges.append({'source': source, 'relation': relation, 'target': target, **attrs})

def is_conservative(a, b):
    return any(a in members and b in members for members in CONSERVATIVE_GROUPS.values())


def main():
    df = pd.read_csv(INPUT_CSV, usecols=['variant', 'fitness'])
    df['variant'] = df['variant'].str.upper().str.strip()
    df = df.drop_duplicates('variant').reset_index(drop=True)
    measured = dict(zip(df['variant'], df['fitness']))

    for aa, (polarity, charge, size, hydropathy) in AA.items():
        node(f'aa:{aa}', 'AminoAcid', symbol=aa, hydropathy=hydropathy,
             polarity=polarity, charge=charge, size=size)
        for attr, value in [('polarity', polarity), ('charge', charge), ('size', size)]:
            prop = f'property:{attr}:{value}'
            node(prop, 'Property', property=attr, value=value)
            edge(f'aa:{aa}', 'has_property', prop)

    for position, wt_aa in zip(POSITIONS, WT):
        node(f'position:{position}', 'Position', position=position, wt_amino_acid=wt_aa)
        edge(f'position:{position}', 'wildtype_amino_acid', f'aa:{wt_aa}')

    for group, members in CONSERVATIVE_GROUPS.items():
        for a, b in combinations(members, 2):
            edge(f'aa:{a}', 'conservative_substitution', f'aa:{b}', group=group, symmetric=True)

    for rid, description in RULES.items():
        node(f'rule:{rid}', 'MutationRule', rule=rid, description=description)


    for variant, fitness in measured.items():
        mutation_count = sum(a != b for a, b in zip(WT, variant))
        node(f'variant:{variant}', 'Variant', sequence=variant,
             mutations_from_wt=mutation_count, measured=True)
        node(f'observation:{variant}', 'FitnessObservation', fitness=float(fitness),
             evidence='known_experiment')
        edge(f'variant:{variant}', 'has_observation', f'observation:{variant}')

        for i, (wt_aa, alt) in enumerate(zip(WT, variant)):
            if wt_aa == alt:
                continue
            position = POSITIONS[i]
            mutation = f'{wt_aa}{position}{alt}'
            mid = f'mutation:{mutation}'
            node(mid, 'Mutation', name=mutation, position=position,
                 from_aa=wt_aa, to_aa=alt,
                 conservative=is_conservative(wt_aa, alt))
            edge(f'variant:{variant}', 'contains_mutation', mid)
            edge(mid, 'occurs_at', f'position:{position}')
            edge(mid, 'changes_from', f'aa:{wt_aa}')
            edge(mid, 'changes_to', f'aa:{alt}')


    contexts = defaultdict(list)
    for variant in measured:
        for i in range(4):
            contexts[(i, variant[:i] + variant[i+1:])].append(variant)

    pair_rows = []
    for (i, background), variants in contexts.items():
        for a, b in combinations(sorted(variants), 2):
            delta = float(measured[b] - measured[a])
            position = POSITIONS[i]
            substitution = f'{a[i]}{position}{b[i]}'
            pid = f'comparison:{a}:{b}'
            node(pid, 'MeasuredSingleSiteComparison', reference_variant=a,
                 test_variant=b, position=position, background=background,
                 substitution=substitution, delta_fitness=delta,
                 reference_fitness=float(measured[a]), test_fitness=float(measured[b]),
                 evidence='observed_fitness_difference_not_global_mutation_effect')
            edge(f'variant:{a}', 'comparison_reference', pid)
            edge(pid, 'comparison_test', f'variant:{b}')
            pair_rows.append({
                'reference_variant': a, 'test_variant': b,
                'position': position, 'background': background,
                'substitution': substitution, 'reference_fitness': float(measured[a]),
                'test_fitness': float(measured[b]), 'delta_fitness': delta,
                'conservative': is_conservative(a[i], b[i]),
            })

    OUT.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(nodes.values()).to_csv(OUT / 'kg_nodes.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(edges).to_csv(OUT / 'kg_edges.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(pair_rows, columns=[
        'reference_variant', 'test_variant', 'position', 'background',
        'substitution', 'reference_fitness', 'test_fitness',
        'delta_fitness', 'conservative',
    ]).to_csv(OUT / 'kg_measured_pairs.csv', index=False, encoding='utf-8-sig')
    graph = {'wildtype': WT, 'positions': list(POSITIONS),
             'source': str(INPUT_CSV), 'rules': RULES,
             'nodes': list(nodes.values()), 'edges': edges}
    (OUT / 'kg_graph.json').write_text(
        json.dumps(graph, ensure_ascii=False, indent=2), encoding='utf-8')
    report = {
        'known_variants': len(measured), 'node_count': len(nodes),
        'edge_count': len(edges), 'matched_single_site_pairs': len(pair_rows),
        'node_types': dict(Counter(n['type'] for n in nodes.values())),
        'output_directory': str(OUT),
    }
    (OUT / 'kg_summary.json').write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
